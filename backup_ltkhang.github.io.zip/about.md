---
layout: page
title: About
permalink: /about/
---

Master student at Graduate Institute of Computer Science and Information Engineering, National Chung Cheng University, Taiwan.

### More Information

#### Conference papers:

T. -K. Luong, T. -D. Tran and G. -T. Le, "DDoS attack detection and defense in SDN based on machine learning," 2020 7th NAFOSTED Conference on Information and Computer Science (NICS), Ho Chi Minh City, Vietnam, 2020, pp. 31-35, doi: 10.1109/NICS51282.2020.9335867.


### Contact me

[luongtankhang123@gmail.com](mailto:luongtankhang123@gmail.com)
